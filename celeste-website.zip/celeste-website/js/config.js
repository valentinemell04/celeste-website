/* ══════════════════════════════════════
   CÉLESTE - Configuration
   Global settings & constants
   ══════════════════════════════════════ */

const CONFIG = {
    // Site info
    siteName: 'CÉLESTE',
    siteUrl: 'https://celeste-fragrance.com',
    
    // Quiz settings
    quiz: {
        autoAdvanceDelay: 400, // ms before auto-advancing to next question
        generatingDelay: 2000, // ms to show "generating" state
    },
    
    // Animation settings
    animation: {
        scrollOffset: 50, // px before nav changes style
    },
    
    // API endpoints (for future use)
    api: {
        baseUrl: '/api',
        endpoints: {
            quiz: '/quiz/submit',
            contact: '/contact',
            newsletter: '/newsletter/subscribe',
        }
    },
    
    // Feature flags
    features: {
        chatbot: false, // Enable when ready
        analytics: true,
        newsletter: true,
    }
};

// Freeze config to prevent accidental modifications
Object.freeze(CONFIG);
Object.freeze(CONFIG.quiz);
Object.freeze(CONFIG.animation);
Object.freeze(CONFIG.api);
Object.freeze(CONFIG.api.endpoints);
Object.freeze(CONFIG.features);
