/* ══════════════════════════════════════
   CÉLESTE - Main JavaScript
   App initialization & global handlers
   ══════════════════════════════════════ */

document.addEventListener('DOMContentLoaded', () => {
    // Initialize components
    initNavigation();
    initFAQ();
    initQuiz();
    initSmoothScroll();
});

/* ─────────────────────────────────
   Navigation
───────────────────────────────── */
function initNavigation() {
    const navbar = document.getElementById('navbar');
    const mobileMenuBtn = document.getElementById('mobileMenuBtn');
    const mobileMenu = document.getElementById('mobileMenu');
    
    // Scroll effect
    if (navbar) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > CONFIG.animation.scrollOffset) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
        });
    }
    
    // Mobile menu toggle
    if (mobileMenuBtn && mobileMenu) {
        mobileMenuBtn.addEventListener('click', () => {
            mobileMenuBtn.classList.toggle('active');
            mobileMenu.classList.toggle('active');
            document.body.style.overflow = mobileMenu.classList.contains('active') ? 'hidden' : '';
        });
        
        // Close mobile menu on link click
        mobileMenu.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                mobileMenuBtn.classList.remove('active');
                mobileMenu.classList.remove('active');
                document.body.style.overflow = '';
            });
        });
    }
}

/* ─────────────────────────────────
   FAQ Accordion
───────────────────────────────── */
function initFAQ() {
    const faqQuestions = document.querySelectorAll('.faq-question');
    
    faqQuestions.forEach(btn => {
        btn.addEventListener('click', () => {
            const answer = btn.nextElementSibling;
            const isOpen = answer.classList.contains('open');
            const isExpanded = btn.getAttribute('aria-expanded') === 'true';
            
            // Close all other FAQs
            document.querySelectorAll('.faq-answer').forEach(a => a.classList.remove('open'));
            document.querySelectorAll('.faq-question').forEach(q => q.setAttribute('aria-expanded', 'false'));
            
            // Toggle current if it was closed
            if (!isOpen) {
                answer.classList.add('open');
                btn.setAttribute('aria-expanded', 'true');
            }
        });
    });
}

/* ─────────────────────────────────
   Quiz
───────────────────────────────── */
function initQuiz() {
    // Initialize quiz instance
    celesteQuiz = new CelesteQuiz();
    
    // Bind all quiz trigger buttons
    const quizTriggers = [
        'heroQuizBtn',
        'navQuizBtn',
        'ctaQuizBtn',
        'mobileQuizBtn'
    ];
    
    quizTriggers.forEach(id => {
        const btn = document.getElementById(id);
        if (btn) {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                celesteQuiz.open();
            });
        }
    });
}

/* ─────────────────────────────────
   Smooth Scroll
───────────────────────────────── */
function initSmoothScroll() {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            const href = this.getAttribute('href');
            
            // Skip if it's just "#" or if it opens the quiz
            if (href === '#' || this.id.includes('Quiz')) return;
            
            const target = document.querySelector(href);
            if (target) {
                e.preventDefault();
                
                const navHeight = document.getElementById('navbar')?.offsetHeight || 0;
                const targetPosition = target.getBoundingClientRect().top + window.pageYOffset - navHeight;
                
                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });
}

/* ─────────────────────────────────
   Utility Functions
───────────────────────────────── */

// Debounce function for scroll/resize events
function debounce(func, wait = 100) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Throttle function for scroll events
function throttle(func, limit = 100) {
    let inThrottle;
    return function(...args) {
        if (!inThrottle) {
            func.apply(this, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}

// Check if element is in viewport
function isInViewport(element) {
    const rect = element.getBoundingClientRect();
    return (
        rect.top >= 0 &&
        rect.left >= 0 &&
        rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
        rect.right <= (window.innerWidth || document.documentElement.clientWidth)
    );
}

/* ─────────────────────────────────
   Analytics (placeholder)
───────────────────────────────── */
function trackEvent(category, action, label = null) {
    if (CONFIG.features.analytics && typeof gtag !== 'undefined') {
        gtag('event', action, {
            'event_category': category,
            'event_label': label
        });
    }
    
    // Console log for development
    console.log(`[Analytics] ${category}: ${action}${label ? ` - ${label}` : ''}`);
}

/* ─────────────────────────────────
   Export for global access
───────────────────────────────── */
window.Celeste = {
    quiz: () => celesteQuiz,
    trackEvent,
    debounce,
    throttle
};
