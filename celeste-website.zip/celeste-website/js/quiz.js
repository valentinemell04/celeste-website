/* ══════════════════════════════════════
   CÉLESTE - Quiz Logic
   Quiz state management & rendering
   ══════════════════════════════════════ */

class CelesteQuiz {
    constructor() {
        this.overlay = document.getElementById('quizOverlay');
        this.container = document.getElementById('quizContainer');
        this.closeBtn = document.getElementById('quizClose');
        
        this.state = {
            step: 'intro',
            questionIndex: 0,
            answers: {},
            selected: null,
            result: null
        };
        
        this.init();
    }
    
    init() {
        if (this.closeBtn) {
            this.closeBtn.addEventListener('click', () => this.close());
        }
        
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && this.isOpen()) {
                this.close();
            }
        });
        
        if (this.overlay) {
            this.overlay.addEventListener('click', (e) => {
                if (e.target === this.overlay) {
                    this.close();
                }
            });
        }
    }
    
    isOpen() {
        return this.overlay?.classList.contains('active');
    }
    
    open() {
        if (this.overlay) {
            this.overlay.classList.add('active');
            this.overlay.setAttribute('aria-hidden', 'false');
            document.body.style.overflow = 'hidden';
            this.render();
        }
    }
    
    close() {
        if (this.overlay) {
            this.overlay.classList.remove('active');
            this.overlay.setAttribute('aria-hidden', 'true');
            document.body.style.overflow = '';
            this.reset();
        }
    }
    
    reset() {
        this.state = {
            step: 'intro',
            questionIndex: 0,
            answers: {},
            selected: null,
            result: null
        };
    }
    
    render() {
        if (!this.container) return;
        
        switch (this.state.step) {
            case 'intro':
                this.renderIntro();
                break;
            case 'questions':
                this.renderQuestion();
                break;
            case 'generating':
                this.renderGenerating();
                break;
            case 'result':
                this.renderResult();
                break;
        }
    }
    
    renderIntro() {
        this.container.innerHTML = `
            <div class="quiz-intro">
                <h1 class="quiz-intro-title">CÉLESTE</h1>
                <p class="quiz-intro-subtitle">Quiz Olfactif</p>
                <p class="quiz-intro-desc">
                    5 questions pour découvrir la fragrance qui vous correspond. 
                    Laissez-vous guider par vos instincts.
                </p>
                <button class="quiz-continue" id="quizStart">Commencer</button>
            </div>
        `;
        
        document.getElementById('quizStart')?.addEventListener('click', () => {
            this.state.step = 'questions';
            this.render();
        });
    }
    
    renderQuestion() {
        const question = QUIZ_DATA.questions[this.state.questionIndex];
        const totalQuestions = QUIZ_DATA.questions.length;
        
        const progressHTML = QUIZ_DATA.questions.map((_, i) => {
            let className = 'quiz-progress-dot';
            if (i < this.state.questionIndex) className += ' completed';
            if (i === this.state.questionIndex) className += ' active';
            return `<div class="${className}"></div>`;
        }).join('');
        
        const optionsHTML = question.options.map(opt => {
            const selectedClass = this.state.selected?.id === opt.id ? 'selected' : '';
            return `
                <div class="quiz-option ${selectedClass}" data-option-id="${opt.id}">
                    <span class="quiz-option-emoji">${opt.emoji}</span>
                    <span class="quiz-option-label">${opt.label}</span>
                </div>
            `;
        }).join('');
        
        this.container.innerHTML = `
            <div class="quiz-progress">${progressHTML}</div>
            <div class="quiz-question-label">Question ${this.state.questionIndex + 1} / ${totalQuestions}</div>
            <h2 class="quiz-question">${question.question}</h2>
            <div class="quiz-options">${optionsHTML}</div>
        `;
        
        this.container.querySelectorAll('.quiz-option').forEach(el => {
            el.addEventListener('click', () => {
                const optionId = el.dataset.optionId;
                this.selectOption(optionId);
            });
        });
    }
    
    selectOption(optionId) {
        const question = QUIZ_DATA.questions[this.state.questionIndex];
        const option = question.options.find(o => o.id === optionId);
        
        if (!option) return;
        
        this.state.selected = option;
        this.render();
        
        setTimeout(() => {
            this.state.answers[question.id] = option;
            this.state.selected = null;
            
            if (this.state.questionIndex < QUIZ_DATA.questions.length - 1) {
                this.state.questionIndex++;
                this.render();
            } else {
                this.state.step = 'generating';
                this.render();
                
                setTimeout(() => {
                    this.state.result = this.generateResult();
                    this.state.step = 'result';
                    this.render();
                }, CONFIG.quiz.generatingDelay);
            }
        }, CONFIG.quiz.autoAdvanceDelay);
    }
    
    renderGenerating() {
        this.container.innerHTML = `
            <div class="quiz-generating">
                <h2 class="quiz-generating-title">Création de votre fragrance...</h2>
                <div class="quiz-spinner"></div>
            </div>
        `;
    }
    
    renderResult() {
        const result = this.state.result;
        if (!result) return;
        
        this.container.innerHTML = `
            <div class="quiz-result">
                <div class="quiz-result-label">Votre Fragrance</div>
                <h1 class="quiz-result-name">${result.nom}</h1>
                <span class="quiz-result-family">${result.famille.nom} — ${result.famille.desc}</span>
                <p class="quiz-result-desc">${result.description}</p>
                
                <div class="quiz-notes-section">
                    <div class="quiz-notes-title">Composition</div>
                    <div class="quiz-notes-grid">
                        <div class="quiz-note-category">
                            <h4>Notes de Tête</h4>
                            <div class="duration">5-30 min</div>
                            ${result.notesTete.map(n => `<div class="quiz-note-item">${n}</div>`).join('')}
                        </div>
                        <div class="quiz-note-category">
                            <h4>Notes de Cœur</h4>
                            <div class="duration">2-4 heures</div>
                            ${result.notesCoeur.map(n => `<div class="quiz-note-item">${n}</div>`).join('')}
                        </div>
                        <div class="quiz-note-category">
                            <h4>Notes de Fond</h4>
                            <div class="duration">4-24 heures</div>
                            ${result.notesFond.map(n => `<div class="quiz-note-item">${n}</div>`).join('')}
                        </div>
                    </div>
                </div>
                
                <button class="quiz-restart" id="quizRestart">Refaire le quiz</button>
            </div>
        `;
        
        document.getElementById('quizRestart')?.addEventListener('click', () => {
            this.reset();
            this.render();
        });
    }
    
    generateResult() {
        const answers = this.state.answers;
        
        // Calculate facettes scores
        const facettes = {};
        Object.values(answers).forEach(answer => {
            if (answer?.mapping) {
                Object.entries(answer.mapping).forEach(([facette, score]) => {
                    facettes[facette] = (facettes[facette] || 0) + score;
                });
            }
        });
        
        // Sort by score
        const sorted = Object.entries(facettes).sort((a, b) => b[1] - a[1]);
        const dominant = sorted[0]?.[0] || 'floral';
        
        // Get family
        const familleKey = QUIZ_DATA.facetteToFamily[dominant] || 'florale';
        const famille = QUIZ_DATA.families[familleKey];
        
        // Generate name
        const prefixes = QUIZ_DATA.names.prefixes;
        const suffixes = QUIZ_DATA.names.suffixes[familleKey] || QUIZ_DATA.names.suffixes.florale;
        const prefix = prefixes[Math.floor(Math.random() * prefixes.length)];
        const suffix = suffixes[Math.floor(Math.random() * suffixes.length)];
        const nom = `${prefix} ${suffix}`;
        
        // Select notes
        const selectNotes = (arr, count) => {
            const shuffled = [...arr].sort(() => Math.random() - 0.5);
            return shuffled.slice(0, count);
        };
        
        return {
            nom,
            famille,
            notesTete: selectNotes(QUIZ_DATA.ingredients.tete, 3),
            notesCoeur: selectNotes(QUIZ_DATA.ingredients.coeur, 3),
            notesFond: selectNotes(QUIZ_DATA.ingredients.fond, 3),
            description: famille.description
        };
    }
}

// Global instance
let celesteQuiz;
