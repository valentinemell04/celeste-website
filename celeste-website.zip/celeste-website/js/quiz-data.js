/* ══════════════════════════════════════
   CÉLESTE - Quiz Data
   Questions, answers & result mappings
   ══════════════════════════════════════ */

const QUIZ_DATA = {
    // Questions
    questions: [
        {
            id: 'moment',
            question: "Quel moment de la journée préférez-vous ?",
            type: 'single',
            options: [
                { 
                    id: 'matin', 
                    emoji: '🌅', 
                    label: 'Le matin', 
                    mapping: { frais: 3, agrume: 2, vert: 1 } 
                },
                { 
                    id: 'aprem', 
                    emoji: '☀️', 
                    label: "L'après-midi", 
                    mapping: { floral: 2, fruite: 2, aromatique: 1 } 
                },
                { 
                    id: 'soir', 
                    emoji: '🌙', 
                    label: 'Le soir', 
                    mapping: { boise: 2, ambre: 2, sensuel: 1 } 
                },
                { 
                    id: 'nuit', 
                    emoji: '✨', 
                    label: 'La nuit', 
                    mapping: { oriental: 3, musque: 2, epice: 1 } 
                }
            ]
        },
        {
            id: 'lieu',
            question: "Où vous sentez-vous le plus vous-même ?",
            type: 'single',
            options: [
                { 
                    id: 'mer', 
                    emoji: '🌊', 
                    label: 'Au bord de la mer', 
                    mapping: { marin: 3, frais: 2, agrume: 1 } 
                },
                { 
                    id: 'foret', 
                    emoji: '🌲', 
                    label: 'En forêt', 
                    mapping: { boise: 3, vert: 2, terreux: 1 } 
                },
                { 
                    id: 'ville', 
                    emoji: '🏙️', 
                    label: 'En ville', 
                    mapping: { cuir: 2, epice: 2, fume: 1 } 
                },
                { 
                    id: 'jardin', 
                    emoji: '🌸', 
                    label: 'Dans un jardin', 
                    mapping: { floral: 3, rose: 2, vert: 1 } 
                }
            ]
        },
        {
            id: 'texture',
            question: "Quelle texture vous attire ?",
            type: 'single',
            options: [
                { 
                    id: 'soie', 
                    emoji: '🪶', 
                    label: 'Soie légère', 
                    mapping: { floral: 2, frais: 2, poudreux: 1 } 
                },
                { 
                    id: 'velours', 
                    emoji: '🍷', 
                    label: 'Velours profond', 
                    mapping: { oriental: 2, ambre: 2, vanille: 1 } 
                },
                { 
                    id: 'lin', 
                    emoji: '🌾', 
                    label: 'Lin naturel', 
                    mapping: { aromatique: 2, vert: 2, frais: 1 } 
                },
                { 
                    id: 'cuir', 
                    emoji: '🖤', 
                    label: 'Cuir souple', 
                    mapping: { cuir: 3, boise: 2, fume: 1 } 
                }
            ]
        },
        {
            id: 'souvenir',
            question: "Quel souvenir olfactif vous touche ?",
            type: 'single',
            options: [
                { 
                    id: 'pain', 
                    emoji: '🥐', 
                    label: 'Pain frais du matin', 
                    mapping: { gourmand: 3, vanille: 2, chaud: 1 } 
                },
                { 
                    id: 'pluie', 
                    emoji: '🌧️', 
                    label: 'Pluie sur terre sèche', 
                    mapping: { terreux: 3, vert: 2, aromatique: 1 } 
                },
                { 
                    id: 'feu', 
                    emoji: '🔥', 
                    label: 'Feu de cheminée', 
                    mapping: { fume: 3, boise: 2, epice: 1 } 
                },
                { 
                    id: 'fleur', 
                    emoji: '💐', 
                    label: 'Bouquet de fleurs', 
                    mapping: { floral: 3, rose: 2, vert: 1 } 
                }
            ]
        },
        {
            id: 'intensite',
            question: "Quelle présence souhaitez-vous ?",
            type: 'single',
            options: [
                { 
                    id: 'discret', 
                    emoji: '🤫', 
                    label: 'Discrète, intime', 
                    mapping: { frais: 2, vert: 2 }, 
                    intensity: 'leger' 
                },
                { 
                    id: 'equilibre', 
                    emoji: '⚖️', 
                    label: 'Équilibrée', 
                    mapping: { floral: 1, boise: 1 }, 
                    intensity: 'modere' 
                },
                { 
                    id: 'affirme', 
                    emoji: '💫', 
                    label: 'Affirmée', 
                    mapping: { oriental: 2, ambre: 1 }, 
                    intensity: 'intense' 
                }
            ]
        }
    ],

    // Olfactory families
    families: {
        florale: { 
            nom: 'Florale', 
            desc: 'Romantique & Intemporelle',
            description: "Une composition florale délicate qui s'ouvre sur des notes lumineuses avant de révéler un cœur romantique et une base poudrée."
        },
        boisee: { 
            nom: 'Boisée', 
            desc: 'Élégante & Sophistiquée',
            description: "Un sillage boisé sophistiqué, alliance parfaite entre la force des essences et l'élégance naturelle."
        },
        fraiche: { 
            nom: 'Fraîche', 
            desc: 'Vivifiante & Lumineuse',
            description: "Une fragrance vivifiante et lumineuse, comme une brise matinale qui éveille les sens."
        },
        orientale: { 
            nom: 'Orientale', 
            desc: 'Envoûtante & Mystérieuse',
            description: "Un voyage sensoriel où épices et résines tissent un voile de mystère envoûtant."
        },
        aromatique: { 
            nom: 'Aromatique', 
            desc: 'Naturelle & Apaisante',
            description: "Une escapade dans la nature méditerranéenne, où les herbes aromatiques rencontrent la fraîcheur."
        },
        gourmande: { 
            nom: 'Gourmande', 
            desc: 'Douce & Réconfortante',
            description: "Une tentation douce et réconfortante aux accents addictifs et chaleureux."
        },
        cuir: { 
            nom: 'Cuir', 
            desc: 'Audacieuse & Caractérielle',
            description: "Une signature intense et caractérielle, mêlant cuir souple et notes fumées."
        }
    },

    // Facette to family mapping
    facetteToFamily: {
        floral: 'florale', 
        rose: 'florale', 
        fruite: 'florale',
        boise: 'boisee', 
        terreux: 'boisee', 
        fume: 'boisee', 
        vert: 'boisee',
        frais: 'fraiche', 
        agrume: 'fraiche', 
        marin: 'fraiche',
        ambre: 'orientale', 
        epice: 'orientale', 
        sensuel: 'orientale', 
        oriental: 'orientale', 
        musque: 'orientale',
        aromatique: 'aromatique', 
        herbace: 'aromatique',
        vanille: 'gourmande', 
        gourmand: 'gourmande', 
        chaud: 'gourmande',
        cuir: 'cuir', 
        poudreux: 'florale'
    },

    // Ingredients database
    ingredients: {
        tete: [
            'Bergamote', 'Citron', 'Pamplemousse', 'Mandarine', 
            'Cassis', 'Poivre rose', 'Cardamome', 'Gingembre', 
            'Menthe', 'Basilic', 'Poire', 'Pomme verte'
        ],
        coeur: [
            'Rose', 'Jasmin', 'Iris', 'Pivoine', 
            'Fleur d\'oranger', 'Tubéreuse', 'Ylang-ylang', 'Géranium', 
            'Lavande', 'Néroli', 'Magnolia', 'Violette'
        ],
        fond: [
            'Santal', 'Cèdre', 'Vétiver', 'Patchouli', 
            'Ambre', 'Musc', 'Vanille', 'Benjoin', 
            'Oud', 'Cuir', 'Tonka', 'Mousse de chêne'
        ]
    },

    // Name generation
    names: {
        prefixes: [
            "L'Essence de", "Secret de", "Éclat de", 
            "Sillage de", "Murmure de", "Aube de",
            "Ombre de", "Lumière de"
        ],
        suffixes: {
            florale: ['Rose', 'Pétale', 'Aurore', 'Jardin', 'Printemps'],
            boisee: ['Cèdre', 'Forêt', 'Nuit', 'Ombre', 'Bois'],
            fraiche: ['Aube', 'Brise', 'Cristal', 'Matin', 'Rosée'],
            orientale: ['Ambre', 'Orient', 'Mystère', 'Soir', 'Encens'],
            aromatique: ['Provence', 'Liberté', 'Herbe', 'Garrigue'],
            gourmande: ['Vanille', 'Délice', 'Douceur', 'Caresse'],
            cuir: ['Cuir', 'Nuit', 'Tabac', 'Fumée']
        }
    }
};

// Freeze data to prevent modifications
Object.freeze(QUIZ_DATA);
