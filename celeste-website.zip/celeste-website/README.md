# CÉLESTE — Site Web

## Structure du Projet

```
celeste-website/
├── index.html              # Page d'accueil principale
├── css/
│   ├── variables.css       # Variables CSS (couleurs, typo, spacing)
│   ├── base.css            # Reset, typographie, utilitaires
│   ├── components.css      # Composants réutilisables (boutons, cartes)
│   ├── layout.css          # Structure de page (nav, sections, footer)
│   ├── quiz.css            # Styles du quiz modal
│   └── responsive.css      # Media queries & responsive design
├── js/
│   ├── config.js           # Configuration globale
│   ├── quiz-data.js        # Données du quiz (questions, familles)
│   ├── quiz.js             # Logique du quiz (classe CelesteQuiz)
│   └── main.js             # Initialisation & handlers globaux
├── assets/
│   └── images/             # Images, logo, favicon
├── pages/                  # Pages secondaires
│   ├── cgv.html
│   ├── mentions-legales.html
│   ├── confidentialite.html
│   ├── livraison.html
│   ├── retours.html
│   └── contact.html
└── README.md
```

## Installation

1. Clone ou télécharge le projet
2. Ouvre `index.html` dans un navigateur

Pour un environnement de développement local :
```bash
# Avec Python
python -m http.server 8000

# Avec Node.js (npx)
npx serve .

# Avec VS Code
# Installer l'extension "Live Server"
```

## Personnalisation

### Couleurs
Modifie `css/variables.css` :
```css
:root {
    --color-black: #0a0a0a;
    --color-cream: #F9F7F4;
    /* ... */
}
```

### Quiz
Modifie `js/quiz-data.js` pour :
- Ajouter/modifier des questions
- Changer les familles olfactives
- Modifier les ingrédients
- Personnaliser les noms générés

### Configuration
Modifie `js/config.js` pour :
- Délais d'animation
- Activer/désactiver des fonctionnalités
- Configurer les endpoints API

## Déploiement

### Netlify
1. Connecte ton repo GitHub
2. Build command: (vide)
3. Publish directory: `/`

### Vercel
1. Import le projet
2. Framework preset: Other
3. Deploy

### OVH / Hébergement classique
1. Upload tous les fichiers via FTP
2. Pointe le domaine vers le dossier

## À faire pour la production

- [ ] Ajouter le favicon (`assets/images/favicon.svg`)
- [ ] Ajouter l'image Open Graph (`assets/images/og-image.jpg`)
- [ ] Compléter les pages légales (CGV, mentions, confidentialité)
- [ ] Configurer Google Analytics
- [ ] Minifier CSS/JS pour la production
- [ ] Ajouter le chatbot
- [ ] Intégrer le système de paiement

## Stack Technique

- HTML5 sémantique
- CSS3 (variables, grid, flexbox)
- JavaScript ES6+ (classes, modules)
- Fonts: Google Fonts (Cormorant, Karla)
- Pas de framework/librairie externe

## Navigateurs Supportés

- Chrome (dernières 2 versions)
- Firefox (dernières 2 versions)
- Safari (dernières 2 versions)
- Edge (dernières 2 versions)
- Mobile: iOS Safari, Chrome Android

## Licence

© 2025 CÉLESTE. Tous droits réservés.
